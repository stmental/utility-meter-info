const requireDir = require('require-dir');

requireDir('./tasks');
